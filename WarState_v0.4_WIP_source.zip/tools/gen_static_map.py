# -*- coding: utf-8 -*-
"""Static map generator for War State (Phase 1)."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
CONFIG=ROOT/"src"/"ReplicatedStorage"/"Shared"/"Config"
OUT=ROOT/"src"/"Workspace"/"Map"
MAT={"SmoothPlastic":272,"Neon":288,"Wood":512,"WoodPlanks":528,"Slate":800,"Concrete":816,"Pebble":864,"Rock":896,"Metal":1088,"Grass":1280,"LeafyGrass":1284,"Sand":1296,"Ground":1360,"Asphalt":1376}
SIDE={"N":(0,-1),"E":(1,0),"S":(0,1),"W":(-1,0)}
def generate():
 game=json.loads((CONFIG/"GameConfig.json").read_text(encoding="utf-8")); return {}
def main(): return 0
if __name__=="__main__": sys.exit(main())
